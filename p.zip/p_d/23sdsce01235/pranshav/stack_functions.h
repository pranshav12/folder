#include <stdlib.h>
#include <stdio.h>
struct Stack
{
    int top;
    int size;
    int *arr;
} Stack;

struct Stack *createStack(int size)
{
    struct Stack *st;
    st = (struct Stack *)malloc(sizeof(struct Stack));
    st->top = -1;
    st->size = size;
    st->arr = (int *)malloc(size * sizeof(int));
    return st;
}

int isFull(struct Stack *st)
{
    if (st->top == st->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int isEmpty(struct Stack *st)
{
    if (st->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void display(struct Stack *st)
{
    int i;
    if (isEmpty(st))
    {
        printf("\nStack is Empty\n");
        return;
    }
    printf("Stack Elemets \n");
    for (i = st->top; i >= 0; i--)
    {
        printf("\n %d --> %d", i, st->arr[i]);
    }
}

void push(struct Stack *st, int value)
{
    if (isFull(st))
    {
        printf("\nStack is Full. Cannot Push data into stack.");
        return;
    }
    st->top++;
    st->arr[st->top] = value;
    // printf("\n %d value pushed on stack and top poinetr of stack is %d\n", value, st->top);
    //  display(st);
}

int pop(struct Stack *st)
{
    int y;
    if (isEmpty(st))
    {
        printf("\nStack is Empty. Data cant be deleted");
        return -1;
    }
    y = st->arr[st->top];
    st->top--;
    // display(st);
    return y;
}

char peek(struct Stack *st)
{
    char y;
    if (isEmpty(st))
    {
        printf("\nStack is Empty. Data cant be deleted");
        return -1;
    }
    y = st->arr[st->top];
    // display(st);
    return y;
}

int peep(struct Stack *st, int index)
{
    if (st->top - index + 1 < 0)
    {
        printf("out of range\n");
        exit(1);
    }
    return st->arr[st->top - index + 1];
}
int change(struct Stack *st, int index, int x)
{
    if (st->top - index + 1 < 0)
    {
        printf("out of range\n");
        exit(1);
    }
    st->arr[st->top - index + 1] = x;
    return st->arr[st->top - index + 1];
}

char *str_reverse(char *e)
{
    int i, j = 0;
    int len = strlen(e);
    char *rev = (char *)(malloc(len * sizeof(char)));
    for (i = len - 1; i >= 0; i--)
    {
        if (e[i] == '(')
        {
            rev[j] = ')';
        }
        else if (e[i] == ')')
        {
            rev[j] = '(';
        }
        else
        {
            rev[j] = e[i];
        }
        j++;
    }

    rev[j] = '\0';
    return rev;
}
int isOperand(char x)
{
    return (x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z');
}
int rank(char x)
{
    if (isOperand(x))
    {
        return 1;
    }
    else if (x == '(' || x == ')')
    {
        return 0;
    }
    else
    {
        return -1;
    }
}
int precedence(char x)
{
    if (isOperand(x))
    {
        return 4;
    }
    switch (x)
    {
    case '^':
        return 3;
    case '*':
    case '/':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return -1;
    }
}
char *infix_postfix(char *e)
{
    int i, k, rank1 = 0;
    int len = strlen(e);
    char *postfix = (char *)malloc(len * sizeof(char));
    struct Stack *s = createStack(len);

    for (i = 0, k = 0; i < len; i++)
    {
        if (isOperand(e[i]))
        {
            push(s, e[i]);

            // postfix[k] = e[i];
            // k++;
        }
        else if (e[i] == '(')
        {
            push(s, e[i]);
        }
        else if (e[i] == ')')
        {
            while (!isEmpty(s) && peek(s) != '(')
            {
                rank1 = rank1 + rank(peek(s));
                postfix[k] = pop(s);
                k++;
            }
            if (rank1 < 0)
            {
                printf("Invalid Expression");
                exit(1);
            }
            if (isEmpty(s))
            {
                printf("Mismatched Parentheses");
                exit(1);
            }
            else
            {
                pop(s);
            }
        }
        else
        {
            while (!isEmpty(s) && precedence(e[i]) <= precedence(peek(s)))
            {
                rank1 = rank1 + rank(peek(s));
                postfix[k] = pop(s);
                k++;
            }
            if (rank1 < 0)
            {
                printf("Invalid Expression");
                exit(1);
            }
            push(s, e[i]);
        }
    }

    while (!isEmpty(s))
    {
        if (peek(s) == '(')
        {
            printf("Mismathced Paranthesis\n");
            exit(1);
        }
        rank1 = rank1 + rank(peek(s));
        postfix[k] = pop(s);
        k++;
        if (rank1 < 0)
        {
            printf("Invalid Expression");
            exit(1);
        }
    }
    if (rank1 == 1)
    {
        postfix[k] = '\0';
        return postfix;
    }
    else
    {
        printf("Invalid Expression");
        exit(1);
    }
}
int evaluatePostfix(char *exp, int a)
{
    int val1, val2;
    if (a == 2)
    {
        exp = strrev(exp);
    }
    int n;
    // Create a stack of capacity equal to expression size
    struct Stack *stack = createStack(strlen(exp));
    int i;

    // See if stack was created successfully
    if (!stack)
        return -1;

    // Scan all characters one by one
    for (i = 0; exp[i]; ++i)
    {
        // If the scanned character is an operand (number here),
        // push it to the stack.
        // if (isdigit(exp[i]))
        //     push(stack, exp[i] - '0');
        if (isalpha(exp[i]))
        {
            printf("enter value of %c", exp[i]);
            scanf("%d", &n);
            push(stack, n);
        }
        // If the scanned character is an operator, pop two
        // elements from stack apply the operator
        else
        {
            if (a == 1)
            {
                val1 = pop(stack);
                val2 = pop(stack);
            }
            else
            {
                val2 = pop(stack);
                val1 = pop(stack);
            }

            switch (exp[i])
            {
            case '+':
                push(stack, val2 + val1);
                break;
            case '-':
                push(stack, val2 - val1);
                break;
            case '*':
                push(stack, val2 * val1);
                break;
            case '/':
                push(stack, val2 / val1);
                break;
            case '^':
                push(stack, pow(val2, val1));
                break;
            }
        }
    }
    return pop(stack);
}
