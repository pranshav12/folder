#include <stdio.h>
#include <stdlib.h>
#include "stack_functions.h"

int main()
{
    int size, choice, conti, x, y, index;
    printf("Enter size of stack");
    scanf("%d", &size);
    struct Stack *s = createStack(size);
Repeat:
    printf("Select Operation:: \n");
    printf("1.Push \n 2. Pop \n 3. Peep \n 4. Change \n 5. Peek \n 6. Display");
    printf("\nEnter Choice:: \n");
    scanf("%d", &choice);
    switch (choice)
    {
    case 1:
        printf("\nEnter value to be pushed into stack");
        scanf("%d", &x);
        push(s, x);
        break;
    case 2:
        y = pop(s);
        // printf("\n%d popped out of stack ", y);
        break;
    case 3:
        printf("Enter index to be fetched\n");
        scanf("%d", &index);
        y = peep(s, index);
        printf("Value %d is present at %d", y, index);
        break;
    case 4:
        printf("Enter index to be fetched\n");
        scanf("%d", &index);
        printf("Enter Value for replacement");
        scanf("%d", &x);
        y = change(s, index, x);
        printf("Value %d at %d is replaced by %d", y, index, x);
        break;
    case 5:
        y = peek(s);
        // printf("\n%d is on the top of stack ", y);
        break;
    case 6:
        display(s);
        break;
    default:
        printf("\n Invalid Choice\n");
        break;
    }
    printf("\nDo you want to Continue??? \n");
    printf("1. Yes \n 2.  No\n");
    printf("\nEnter Choice\n");
    scanf("%d", &conti);
    if (conti == 1)
    {
        goto Repeat;
    }
    return 0;
}
