#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "stack_functions.h"

int main()
{
    int ch, ans;
    char expression[50];
    char *postfix, *prefix;
    printf("Enter the expression: \n");
    scanf("%s", expression);
    printf("\nInfix Expression:: %s\n", expression);
    printf("\nEnter 1 for Postfix\n");
    printf("\nEnter 2 for Prefix\n");
    printf("\nEnter Your choice::\n");
    scanf("%d", &ch);
    switch (ch)
    {
    case 1:
        postfix = infix_postfix(expression);
        printf("Postfix :: %s\n", postfix);
        ans = evaluatePostfix(postfix, 1);
        printf("Answer: %d\n", ans);
        break;
    case 2:
        prefix = infix_postfix(str_reverse(expression));
        printf("Prefix :: %s\n", str_reverse(prefix));
        ans = evaluatePostfix(str_reverse(prefix), 2);
        printf("Answer: %d\n", ans);
        break;
    default:
        printf("\n Invalid Choice \n");
    }
    return 0;
}